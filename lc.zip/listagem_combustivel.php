<?php
@$id_funcionario=$_GET['idfuncionario'];
@$id_viatura=$_GET['idviatura'];
@$procura=$_GET['procura'];
@$di=$_POST['data_inicio'];
@$df=$_POST['data_fim'];


//definir a font a usar
echo '<font style="font-family:Arial, Helvetica, sans-serif;font-size:14px;">';
if ($id_funcionario>0){
	//obter detalhes do funcionario-----------------------------------------------------
$q_dados="select * from funcionario where id_funcionario=".$id_funcionario;
$r_dados=mysql_query($q_dados);
$n_dados=mysql_num_rows($r_dados);
echo '<b>Nome: </b>'.mysql_result($r_dados,0,'nome_funcionario').'<br><b>Grupo: </b>'.mysql_result($r_dados,0,'grupo_funcionario');
echo '<br><br><br><form method=POST action="index.php?procura=1&pagina=listagemcombustivel&idfuncionario='.$id_funcionario.'">';

	//teste codigo insercao data
	echo "
	<script>
		$(function() {
			$( '#datepicker_inicio' ).datepicker();
			$( '#datepicker_fim' ).datepicker();
		});
	</script>";
	echo '
Data Inicio: <input  name="data_inicio" size=7 id="datepicker_inicio" type="text"> -> 
Data Fim: <input  name="data_fim" size=7 id="datepicker_fim" type="text"><br>';

echo '
<button type="submit" value="Filtrar">Filtrar</button>
</form>';
echo '<a id="hor-minimalist-b" href="index.php?pagina=listagemcombustivel&idfuncionario='.$id_funcionario.'">Ver todos os movimentos</a>';
$condicao="where mov_combustivel.id_funcionario=".$id_funcionario;
}else{
	//obter detalhes da viatura--------------------------------------------------------
$q_dados="select * from viaturas where id_viatura=".$id_viatura;
$r_dados=mysql_query($q_dados);
$n_dados=mysql_num_rows($r_dados);
echo '<b>Viatura :: </b>'.mysql_result($r_dados,0,'desc_viatura').'<br><b>Tipo :: </b>'.mysql_result($r_dados,0,'tipo_viatura');
echo '<br><br><br><form method=POST action="index.php?procura=1&pagina=listagemcombustivel&idviatura='.$id_viatura.'">
';

	//teste codigo insercao data
	echo "
	<script>
		$(function() {
			$( '#datepicker_inicio' ).datepicker();
			$( '#datepicker_fim' ).datepicker();
		});
	</script>";
	echo '
Data Inicio: <input  name="data_inicio" size=7 id="datepicker_inicio" type="text"> -> 
Data Fim: <input  name="data_fim" size=7 id="datepicker_fim" type="text"><br>';

echo '
<button type="submit" value="Filtrar">Filtrar</button>
</form></font>';
echo '<a id="hor-minimalist-b" href="index.php?pagina=listagemcombustivel&idviatura='.$id_viatura.'">Ver todos os movimentos</a>';
$condicao="where mov_combustivel.id_viatura=".$id_viatura;
}

		//calcular totais dos kms/horas e litros-------------------------------------
		if($procura==1){
			//query com data
		$q_soma_combustivel="select mov_combustivel.id_movcombustivel, mov_combustivel.data, (max(mov_combustivel.kms_viatura)-min(mov_combustivel.kms_viatura)) as 'dif', sum(mov_combustivel.valor_movimento) as 'soma_litros', viaturas.desc_viatura, funcionario.nome_funcionario
			from mov_combustivel
			inner join viaturas on viaturas.id_viatura = mov_combustivel.id_viatura
			inner join funcionario on funcionario.id_funcionario=mov_combustivel.id_funcionario
			".$condicao."
			and mov_combustivel.valor_movimento > 0
			and date(mov_combustivel.data) >= '".@$di."' and date(mov_combustivel.data) <= '".@$df."'
			order by date(mov_combustivel.data) desc";		
		}else{
		//query sem data
		$q_soma_combustivel="select mov_combustivel.id_movcombustivel, mov_combustivel.data, (max(mov_combustivel.kms_viatura)-min(mov_combustivel.kms_viatura)) as 'dif', sum(mov_combustivel.valor_movimento) as 'soma_litros', viaturas.desc_viatura, funcionario.nome_funcionario
			from mov_combustivel
			inner join viaturas on viaturas.id_viatura = mov_combustivel.id_viatura
			inner join funcionario on funcionario.id_funcionario=mov_combustivel.id_funcionario
			".$condicao."
			and mov_combustivel.valor_movimento > 0
			order by date(mov_combustivel.data) desc";		
		}
		$r_soma_combustivel=mysql_query($q_soma_combustivel);
		$n_soma_combustivel=mysql_num_rows($r_soma_combustivel);
		//--------------------------------------------------------------------------
		echo'
		<table id="hor-minimalist-b" summary="motd">
		<th colspan=8><td></td></th>
		<tr>
			<td colspan=4 align="right">Totais:</td>
			<td align="center">'.mysql_result($r_soma_combustivel, 0,'dif').' H/Kms</td>
			<td align="center"> Total Litros :: '.mysql_result($r_soma_combustivel, 0,'soma_litros').' L</td>
			<td colspan=2></td>
		</tr>
		<tr>
			<td align="right" colspan=6>Consumo Estimado :: <b>'.@round((((mysql_result($r_soma_combustivel, 0,'soma_litros')*100)/mysql_result($r_soma_combustivel, 0,'dif'))), 2).'</b> L/100</td>
			<td colspan=2></td>	
		</tr>
		</table>';



//ultimos registos do funcionario
	if($procura==1){
		//query com data
		$q_mov_combustivel="select mov_combustivel.id_movcombustivel, mov_combustivel.data, mov_combustivel.kms_viatura, mov_combustivel.valor_movimento, viaturas.desc_viatura, funcionario.nome_funcionario
from mov_combustivel
inner join viaturas on viaturas.id_viatura = mov_combustivel.id_viatura
inner join funcionario on funcionario.id_funcionario=mov_combustivel.id_funcionario
".$condicao."
and mov_combustivel.valor_movimento > 0
and date(mov_combustivel.data) >= '".@$di."' and date(mov_combustivel.data) <= '".@$df."'
order by date(mov_combustivel.data) desc";		
	}else{
		//query sem data
		$q_mov_combustivel="select mov_combustivel.id_movcombustivel, mov_combustivel.data, mov_combustivel.kms_viatura, mov_combustivel.valor_movimento, viaturas.desc_viatura, funcionario.nome_funcionario
from mov_combustivel
inner join viaturas on viaturas.id_viatura = mov_combustivel.id_viatura
inner join funcionario on funcionario.id_funcionario=mov_combustivel.id_funcionario
".$condicao."
and mov_combustivel.valor_movimento > 0
order by date(mov_combustivel.data) desc";		
	}
		
	$r_mov_combustivel=mysql_query($q_mov_combustivel); //resultados da query
	$n_mov_combustivel=mysql_num_rows($r_mov_combustivel); //numero de linhas
	
	//desenhar tabelas com os registos	
		echo '<table id="hor-minimalist-b" summary="motd">
		<thead>
		<tr>
			<th colspan="5">Combustivel utilizado</th>
		</tr>
		<tr>
			<th></th>
			<th>Data e Hora</th>
			<th>Colaborador</th>
			<th>Viatura</th>
			<th>Horas / Kms</th>
			<th>Litros</th>
			<th colspan=3>Opera��es</th>
		</tr>
		</thead>
		<tbody>';
		if($n_mov_combustivel>0){
		for($i=0;$i<$n_mov_combustivel;$i++){ //obter linhas dos movimentos
			echo '<tr>
					<td>
						<img src="gasoleo.png" height="20" border=0>
					</td>
					<td>
						'.mysql_result($r_mov_combustivel,$i,'data').'
					</td>
					<td>
						'.mysql_result($r_mov_combustivel,$i,'nome_funcionario').'
					</td>					
					<td>
						'.mysql_result($r_mov_combustivel,$i,'desc_viatura').'
					</td>
					<td align="center">
						'.mysql_result($r_mov_combustivel,$i,'kms_viatura').'
					</td>
					<td align="center">
						'.mysql_result($r_mov_combustivel,$i,'valor_movimento').' L
					</td>			
					<td align="center">
						<a href="/admin/index.php?pagina=editarcomb&id='.mysql_result($r_mov_combustivel,$i,'id_movcombustivel').'"><img src="editar.png" border=0></a>
					</td>
					<td align="center">
						<input type="image" onclick="apagar(\'/admin/index.php?pagina=listagemcombustivel&idfuncionario='.$id_funcionario.'&func=apagar&tipo=comb&id='.mysql_result($r_mov_combustivel,$i,'id_movcombustivel').'\')" src="delete.gif">
					</td>								
			</tr>';
		}
		}
		echo '
		</tbody>
	</table>';	
?>