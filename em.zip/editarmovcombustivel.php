<?php
	$id=$_GET['id'];
	@$guardar=$_GET['guardar'];
	@$idv=$_GET['idv'];
	if($guardar==1){
		$valor=$_POST['valor'];
		$kms=$_POST['kms'];
		$novo=$_GET['novo'];
		if(isset($novo)&&$novo!=1){
			$q_guardar="UPDATE mov_combustivel SET kms_viatura=".$kms." ,valor_movimento='".$valor."' where id_movcombustivel=".$id;
		}else{
			//sem uso
		}

		if(mysql_query($q_guardar)){
			$msg= 'Altera��es salvas com sucesso!';
		}else{
			$msg='Erro ao gravar as altera��es!';
		}
		echo '
		<script type="text/javascript">
			alert("'.$msg.'");
			window.location="index.php?pagina=listagemcombustivel&idviatura='.$idv.'";
		</script>
		';
	}

	$q_mc="select * from mov_combustivel where id_movcombustivel=".$id;
	$r_mc=mysql_query($q_mc);
	$n_mc=mysql_num_rows($r_mc);
	
	echo '<table id="hor-minimalist-b" summary="motd"><thead><th>EDITAR MOVIMENTO DE COMBUSTIVEL '.@$id.'</th></thead><tbody><tr></tr><tr><td><form method="POST" action="index.php?pagina=editarcomb&id='.$id.'&guardar=1&idv='.mysql_result($r_mc,0,'id_viatura').'&novo='.@$novo.'">
	Data: <input type="text" size=20 name="data" value="'.mysql_result($r_mc,0,'data').'"><br>
	Horas/Kilometros: <input type="text" size=10 name="kms" value="'.mysql_result($r_mc,0,'kms_viatura').'"><br>
	Litros:<input type="text" size=3 name="valor" value="'.mysql_result($r_mc,0,'valor_movimento').'">
		<br><br>';
	echo '</td></tr><tr><td align="right">'.@$msg.'<br><button type="submit">Guardar Altera��es</button></form></td></tr></tbody></table>';
?>