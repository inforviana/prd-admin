<?php
//ponto dos funcionarios
echo 'Ponto dos Funcionarios - '.date('j-m-Y').'<br><br>';

$q_ponto_funcionarios="select mov_viatura.id_funcionario, funcionario.nome_funcionario, (sum(mov_viatura.horas_viatura)/60) as 'horas'
from mov_viatura
join funcionario on funcionario.id_funcionario = mov_viatura.id_funcionario
where date(mov_viatura.data)=date(now())
group by mov_viatura.id_funcionario";

$r_ponto_funcionarios=mysql_query($q_ponto_funcionarios);
$n_ponto_funcionarios=mysql_num_rows($r_ponto_funcionarios);

echo '<table><thead><th><u>Nome</u></th><th><u>Horas</u></th></thead>';
for($i=0;$i<$n_ponto_funcionarios;$i++){
	echo '<tr><td><a href="index.php?pagina=listagemhoras&idfuncionario='.mysql_result($r_ponto_funcionarios,$i,'id_funcionario').'"><img height=16 src="./images/check.png" border=0></a><font style="text-align:right;font-family:Arial, Helvetica, sans-serif;font-size:11px;">'.mysql_result($r_ponto_funcionarios,$i,'nome_funcionario').'</font></td><td valign="middle" align="center">'.intval(mysql_result($r_ponto_funcionarios,$i,'horas')).'</td></tr>';
}
echo '</table><br><br>';
?>